<?php
session_start();
//set form query values
$servername = "localhost";
$username = "webapp17Us3r";
$password = "5DfJa2aduPkQtmEK";
$dbname = "playground17";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}
else
{
	//echo("<br>Connection established<br>");
}


function displayStars($starLevel)
{
	$starString = "";
	if ($starLevel>=0.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=0.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=1.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=1.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=2.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=2.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=3.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=3.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=4.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=4.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	return $starString;
}
function handleQueries($board) //This should be either "Orders" or "Offers"
{
	if (empty($_POST["emailRequest"])){
		$_POST["emailRequest"] = NULL;
	}
	if (empty($_POST["locRequest"])){
		$_POST["locRequest"] = NULL;
	}
	//checking if first time when post vars will be null
	$eRequest = is_null($_POST["emailRequest"]);
	$lRequest = is_null($_POST["locRequest"]);
	//fixing up the string as well as the queries
	if ($eRequest!=1){
		$eRequest = "Email ='".$conn->real_escape_string($_POST["emailRequest"])."'";
	}
	if ($lRequest!=1){
		$lRequest = "FoodPlace ='".$conn->real_escape_string($_POST["locRequest"])."'";
	}
	return "SELECT * FROM BCPDelivery_".$board." WHERE $eRequest AND $lRequest";
}
function acceptOrdersOffers($board)
{
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	$rowCounter = 0;
	while(isset($_POST["accept".$board."ID".$rowCounter]))
	{
		if (!empty($_POST["accept".$board."ID".$rowCounter])) 
		{
			$acceptRequest = "UPDATE BCPDelivery_".$board." SET AcceptedEmail='".$_POST['accept'.$board.'Email'.$rowCounter]."' WHERE ID=".$_POST['accept'.$board.'ID'.$rowCounter];
		}
		if (mysqli_query($conn, $acceptRequest)) {
			//echo "<br>Record ".$rowCounter." updated successfully";
		} else {
			//echo "<br>Error updating record ".$rowCounter.": " . mysqli_error($conn);
		}
		$rowCounter = $rowCounter + 1;
	}
}
function retrieveRatings($email) //consider making connection a session value
{
	//set form query values
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		//echo("<br>Connection established<br>");
	}
	$outputString = "";
	$sql = "SELECT * FROM BCPDelivery_Profile WHERE Email='".$email."'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if($row["NumberRatings"] != 0) {
				$outputString = $outputString.round($row["RatingSum"]/$row["NumberRatings"], 2);
			}
			else {
				$outputString = 0;
			}
		}
	} else {
		//echo "0 results";
		//echo ("Output: ".$outputString);
	}
	return $outputString;
}
function validateUser() //checks userID cookie/session variable
{
	if($_SESSION['userID'] === "")
	{
		header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/' ) ;
		exit;
	}
}
validateUser();
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Community Board</title>

<style>
	#posting {
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		width: 100%;
	}
	
	#posting td, #posting th {
		border: 1px solid #bfbfbf;
		padding: 8px;
	}
	
	#posting tr:nth-child(even){background-color: #ddd;}
	
	#posting tr:hover {background-color: #9A9A9A;}
	
	#posting th {
		padding-top: 12px;
		padding-bottom: 12px;
		text-align: left;
		background-color: #4CAF50;
		color: white;
	}
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
</style>
</head>

<body>
<div align="right">
    <form method="post" action="profile.php">
        <button type="submit">Profile</button>
    </form>
</div>

<br>
<?php

//HANDLE ACCEPT REQUESTS
acceptOrdersOffers("Orders");
acceptOrdersOffers("Offers");


echo("
	<div class=\"row container\">
	  <div class=\"column\" style=\"background-color:#aaa;\">
");
//ORDERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Orders"));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Request</th><th>Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Price</th><th>Markup</th><th>Poster</th><th></th><th>Rating</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if ($row["AcceptedEmail"] === NULL and (date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime($row["DeliveryTime"])))) 
		{
			//Determine Rating
			$ratings = retrieveRatings($row["Email"]);
			echo(
					"<tr>".
					"<td>".$row["Order"]."</td>".
					"<td>".$row["FoodPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["ApproxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MaxMarkup"], 2)."</td>". //parse cents
					"<td>".
						"<form action=\"profile.php\" method=\"POST\" name=\"profileRequestForm\"/>".
							"<input type=\"hidden\" name=\"userProfileRequest\" value=\"".$row["ID"]."\"/>".
							"<button type=\"submit\">".$row["Email"]."</button>".
						"</form>".
					"</td>". //parse for name maybe?
					"<td>".
						"<form action=\"jobListings.php\" method=\"POST\" name=\"orderForm\"/>".
							"<input type=\"hidden\" name=\"accept"."Orders"."ID".$rowCounter."\" value=\"".$row["ID"]."\"/>".
							"<input type=\"hidden\" name=\"accept"."Orders"."Email".$rowCounter."\" value=\"".$row["Email"]."\"/>".
							"<button type=\"submit\">Accept Request</button>".
						"</form>".
					"</td>".
					"<td>".displayStars($ratings)."</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 results";
}

echo("
  </div>
  <div class=\"column\" style=\"background-color:#bbb;\">
");
//OFFERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Offers"));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Offer</th><th>Order Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Max Price</th><th>Markup</th><th>Poster</th><th></th><th>Rating</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if ($row["AcceptedEmail"] === NULL and (date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime($row["DeliveryTime"])))) 
		{
			//Determine Rating
			$ratings = retrieveRatings($row["Email"]);
			echo(
					"<tr>".
					"<td>".$row["OrderItem"]."</td>".
					"<td>".$row["OrderPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["MaxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MarkupPrice"], 2)."</td>". //parse cents
					"<td>".
						"<form action=\"profile.php\" method=\"POST\" name=\"profileRequestForm\"/>".
							"<input type=\"hidden\" name=\"userProfileRequest\" value=\"".$row["ID"]."\"/>".
							"<button type=\"submit\">".$row["Email"]."</button>".
						"</form>".
					"</td>". //parse for name maybe?
					"<td>".
						"<form action=\"jobListings.php\" method=\"POST\" name=\"offerForm\"/>".
							"<input type=\"hidden\" name=\"accept"."Offers"."ID".$rowCounter."\" value=\"".$row["ID"]."\"/>".
							"<input type=\"hidden\" name=\"accept"."Offers"."Email".$rowCounter."\" value=\"".$row["Email"]."\"/>".
							"<button type=\"submit\">Accept Offer</button>".
						"</form>".
					"</td>".
					"<td>".displayStars($ratings)."</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 results";
}

echo("
  </div>
</div>
");

echo("
	<form action=\"jobListings.php\" method=\"post\" name=\"searchForm\">
	<fieldset>
		Search by Location: <input type=\"text\" maxlength=\"30\" name=\"locRequest\" value=\"".$_POST['locRequest']."\"/>
		Search by Email: <input type=\"text\" maxlength=\"20\" name=\"emailRequest\" value=\"".$_POST['emailRequest']."\"/>
		<button type=\"submit\">Search</button>
	</fieldset>
	</form>
");
$conn->close();

?>

</body>
</html>