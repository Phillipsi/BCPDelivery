<?php
if(isset($_POST['register']))
{
	$email=$_POST['email'];
	$pass= $_POST['password'];
	$firstname = $_POST['first'];
	$lastname = $_POST['last'];
	$code=substr(md5(mt_rand()),0,15);
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	echo "Connected successfully<br>";
	$domain = (substr($email, strpos($email, "@")+1, strlen($email)));
	if ($domain ==1 or strlen($domain)<1)
	{
		echo ("Email not within approved domains.");
		exit();
	}
	// Create connection
	$result = mysqli_query($conn, "SELECT * FROM BCPDelivery_ApprovedDomains WHERE domain = '".$domain."'");
	if(mysqli_num_rows($result)==0){
		echo ("Email not within approved domains.");
		exit();
	}
	$sql="insert into BCPDelivery_UnverifiedProfile (FirstName, LastName, Email, Password, code) values('$firstname', '$lastname', '$email','$pass','$code')";
	if (mysqli_query($conn, $sql)) {
		echo "Profile Created!";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	$message = "Your Activation Code is ".$code."";
    $to=$email;
    $subject="Activation Code For BCP Delivery";
    $from = 'Josh.Holden18@bcp.org';
    $body='Your Activation Code is '.$code.' Please Click On This link http://times.bcp.org/webapps18/josh18/BCPDelivery/verification.php?code='.$code.' to activate your account.';
    $headers = "From:".$from;
    mail($to,$subject,$body,$headers);
	
	echo "<br>An Activation Code Is Sent To You. Check Your Email Please.";
}
if(isset($_GET['code']))
{
	$code=$_GET['code'];
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	echo "Connected successfully<br>";
	$sql="select FirstName, LastName, Email,Password from BCPDelivery_UnverifiedProfile where code='$code'";
	$result = mysqli_query($conn, $sql);
	if(mysqli_num_rows($result)==1)
	{
		while($row=mysqli_fetch_array($result))
		{
			$firstname=$row['FirstName'];
			$lastname=$row['LastName'];
			$email=$row['Email'];
			$password=$row['Password'];
		}
		$result=mysqli_query($conn, "select * from BCPDelivery_Profile where Email = '$email'");
		if(mysqli_num_rows($result)==1)
		{
			exit();
		}
		$sql= "insert into BCPDelivery_Profile (FirstName, LastName, Email, Password, RatingSum, NumberRatings, Comments) values('$firstname','$lastname','$email','$password', 0, 0, NULL)";
			if (mysqli_query($conn, $sql)) {
			echo "Profile Created!";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
}

?>