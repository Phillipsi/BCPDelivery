<?php
$servername = "localhost";
$username = "webapp17Us3r";
$password = "5DfJa2aduPkQtmEK";
$dbname = "playground17";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}
else
{
	echo("<br>Connection established<br>");
}

if($_POST["email"] != "" and $_POST["password"] != "")
{
	$rEmail = $_POST["email"];
	$rPassword = $_POST["password"];
}

echo("Username: ".$rEmail." Password: ".$rPassword."<br>");
$sql = "SELECT * FROM BCPDelivery_Profile WHERE Email='".$rEmail."'";
$result = mysqli_query($conn, $sql);
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
		if($row["Password"] === $rPassword) {
			session_start();
			$_SESSION['userID'] = $row["ID"];
			$_SESSION['userEmail'] = $row["Email"];
			echo("userID: ".$_SESSION['userID']." userEmail: ".$_SESSION["userEmail"]."<br>" );
			echo("login successful!");
			print_r($_SESSION);
			header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/jobListings.php' ) ;
			exit;
		}
		else {
			//wrong password
			echo("wrong password");
			header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/index.html' ) ;
			exit;
		}
	}
} else {
	//wrong email
	echo("wrong email");
	header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/index.html' ) ;
	exit;
}
	
?>