<form action="jobListings.php">
    <input type="submit" value="Back to job listings" />
</form>
<?php
//add back buttons

$servername = "localhost";
$username = "webapp17Us3r";
$password = "5DfJa2aduPkQtmEK";
$dbname = "playground17";
$email = "Josh.Holden18@bcp.org";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";

$email = "Josh.Holden18@bcp.org";
$hour = $_REQUEST['deliveryhour'];
if($_REQUEST['ampm']==="PM"){
	$hour = $hour+12;
}
$minute = $_REQUEST['deliveryminute'];
$month = $_REQUEST['deliverymonth'];
$day = $_REQUEST['deliveryday'];
if($hour<10){
	$hour = "0".$hour;
}
if ($minute<10){
	$minute = "0".$minute;
}
if($month<10){
	$month = "0".$month;
}
if ($day<10){
	$day = "0".$day;
}
$deliverytime = trim("2017-".$month."-".$day."T".$hour.":".$minute.":00");
if( strlen($deliverytime) > 100 || strlen($deliverytime)< 1 ) {
	exit();
}


$maxprice = trim($_REQUEST['maxprice']);
if( strlen($maxprice) > 100 || strlen($maxprice)< 1 ) {
	exit();
}
$maxprice = $conn->real_escape_string($maxprice);

$markup = trim($_REQUEST['markup']);
if( strlen($markup) > 100 || strlen($markup)< 1 ) {
	exit();
}
$markup = $conn->real_escape_string($markup);

$ordertime = trim($_REQUEST['ordertime']);
if( strlen($ordertime) > 100 || strlen($ordertime)< 1 ) {
	exit();
}
$ordertime = $conn->real_escape_string($ordertime);
$restaurant = trim($_REQUEST['restaurant']);
if( strlen($restaurant) > 100 || strlen($restaurant)< 1 ) {
	exit();
}
$restaurant = $conn->real_escape_string($restaurant);

$numRequests = $_REQUEST['numOffers'];
for ($i = 1; $i <= $numRequests; $i++)
{
	$sql = "INSERT INTO `BCPDelivery_Offers` (`MaxPrice`, `MarkupPrice`, `DeliveryTime`, `OrderPlace`, `OrderTime`, `Email`)
	VALUES ('".$maxprice."', '".$markup."', '".$deliverytime."', '".$restaurant."', '".$ordertime."', '".$email."')";
	if (mysqli_query($conn, $sql)) {
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
mysqli_close($conn);
?>