<?php

$servername = "localhost";
$username = "webapp17Us3r";
$password = "5DfJa2aduPkQtmEK";
$dbname = "playground17";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully<br>";
$stars = trim($_REQUEST['star']);
if( strlen($stars)<1 ) {
	exit();
}
$stars = intval($stars);
$email = $_POST["rateEmail"];
$result = mysqli_query($conn,"SELECT RatingSum, NumberRatings FROM BCPDelivery_Profile WHERE Email = '".$email."'");
$row = mysqli_fetch_array($result);
$stars = $stars +$row["RatingSum"];
$numratings = $row["NumberRatings"]+1;
$sql = "UPDATE `BCPDelivery_Profile` SET RatingSum = ".$stars.", NumberRatings = ".$numratings." WHERE Email = '".$email."'";
if (mysqli_query($conn, $sql)) {
		echo "New rating created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
$comment = trim($_REQUEST['comment']);
if( strlen($comment)>0 ) {
	$comment = $conn->real_escape_string($comment);
	$star = trim($_REQUEST['star']);
	$star = intval($star);
	$sql = "INSERT INTO `BCPDelivery_Ratings` (`Comment`, `Stars`, `email`)
	VALUES ('".$comment."', '".$star."', '".$email."')";
	if (mysqli_query($conn, $sql)) {
		echo "<br>New comment added";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>