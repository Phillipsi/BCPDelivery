<?php
session_start();
$servername = "localhost";
$username = "webapp17Us3r";
$password = "5DfJa2aduPkQtmEK";
$dbname = "playground17";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

function retrieveRatings($userID) //consider making connection a session value
{
	//set form query values
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		//echo("<br>Connection established<br>");
	}
	$outputString = "";
	$sql = "SELECT * FROM BCPDelivery_Profile WHERE ID='".$userID."'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if($row["NumberRatings"] != 0) {
				$outputString = $outputString.round($row["RatingSum"]/$row["NumberRatings"], 2);
			}
			else {
				$outputString = 0;
			}
		}
	} else {
		//echo "0 results";
		//echo ("Output: ".$outputString);
	}
	return $outputString;
}
function handleQueries($board, $userID) //This should be either "Orders" or "Offers", specific to profile
{
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	$sql = "SELECT * FROM BCPDelivery_Profile WHERE ID='".$userID."'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			if($row["NumberRatings"] != 0) {
				$userEmail = $row["Email"];
			}
			else {
				$userEmail = NULL;
			}
		}
	} else {
		//echo "0 results";
		//echo ("Output: ".$outputString);
	}
	
	$idRequest = "ID ='".$userEmail."'";
	$aidRequest = "AcceptedEmail = '".$userEmail."'";
	return "SELECT * FROM BCPDelivery_".$board." WHERE $idRequest AND $aidRequest";
}
function cancelOrdersOffers($board)
{
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	$rowCounter = 0;
	while(isset($_POST["accept".$board."ID".$rowCounter]))
	{
		if (!empty($_POST["accept".$board."ID".$rowCounter])) 
		{
			$acceptRequest = "DELETE FROM BCPDelivery_".$board." WHERE ID=".$_POST['cancel'.$board.'ID'.$rowCounter];
		}
		if (mysqli_query($conn, $acceptRequest)) {
			//echo "<br>Record ".$rowCounter." updated successfully";
		} else {
			//echo "<br>Error updating record ".$rowCounter.": " . mysqli_error($conn);
		}
		$rowCounter = $rowCounter + 1;
	}
}
function displayStars($starLevel)
{
	$starString = "";
	if ($starLevel>=0.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=0.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=1.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=1.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=2.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=2.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=3.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=3.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	if ($starLevel>=4.75){$starString = $starString."<img src='starfullsmall.png'>";}
	else if ($starLevel>=4.25){$starString = $starString."<img src='starhalfsmall.png'>" ;}
	else{ $starString = $starString."<img src='staremptysmall.png'>" ;}
	return $starString;
}
function updateProfile($ID, $firstname, $lastname, $comments)
{
	$servername = "localhost";
	$username = "webapp17Us3r";
	$password = "5DfJa2aduPkQtmEK";
	$dbname = "playground17";
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	$editRequest = "UPDATE BCPDelivery_Profile SET FirstName='".$firstname."', LastName='".$lastname."', Comments='".$comments."' WHERE ID='".$ID."'";
	if (mysqli_query($conn, $editRequest)) {
		//echo "<br>Record ".$rowCounter." updated successfully";
	} else {
		echo "<br>Error updating record ".$email.": " . mysqli_error($conn);
	}
}
function validateUser() //checks userID cookie/session variable
{
	if($_SESSION['userID'] === "")
	{
		header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/' ) ;
		exit;
	}
}
validateUser();


/*function alert($msg) {
		else{
        $cookie_name = "user";
        $cookie_value = "sanshengwangchuanwushang";
        setcookie($cookie_name, $cookie_value, time()+300);
    }
    echo "<script type='text/javascript'>alert('$msg');</script>";
    }
    if($_COOKIE[$cookie_name]=="sanshengwangchuanwushang") {
     echo "welcome!";
    alert("success!");
    } else {
         header('Location: http://times.bcp.org/webapps18/phi18/loginForm.html');  
    }
	*/


cancelOrdersOffers("Orders");
cancelOrdersOffers("Offers");

if($_POST["userProfileRequest"] != "")
{
	$userID = $_POST["userProfileRequest"];
}
else
{
	$userID = $_SESSION['userID'];
}
$loggedin = false;
if($_SESSION['userID'] === $userID)
{
	$loggedin = true;
}

$first = $_POST['firstNameForm'];
$last = $_POST['lastNameForm'];
$comment = $_POST['commentsForm'];

if($first != "" or $last != "" or $comment != "")
{
	updateProfile($userID, $first, $last, $comment);
}

$sql = "SELECT * FROM BCPDelivery_Profile WHERE ID = '".$userID."'";
$result = mysqli_query($conn, $sql);

//Display info
if ($result->num_rows > 0) 
{
	while($row = $result->fetch_assoc())//returns Profile info
	{
		//Display name
		if ($loggedin === true)
		{
			echo("<div>".
				"<form action=\"profile.php\" method=\"POST\" id=\"nameForm\"/>".
				"<input type=\"text\" maxlength=\"20\" name=\"firstNameForm\" value=\"".$row["FirstName"]."\"/>".
				"<input type=\"text\" maxlength=\"20\" name=\"lastNameForm\" value=\"".$row["LastName"]."\"/>".
				"<button type=\"submit\">Update Profile</button>".
				"</form>".
				"<br><textarea name=\"commentsForm\" form=\"nameForm\">".$row["Comments"]."</textarea>".
				"</div>");
		}
		else
		{
			echo("<div>".$row["FirstName"]." ".$row["LastName"]."<br>".$row["Comments]"]."</div>");
		}
		//Display email
		echo("<div>".$row["Email"]."</div>");
		//Display stars
		echo("<div>".displayStars(retrieveRatings($row["ID"]))."</div>");
		
		echo("<h3>Comments</h3>");
		
		$sql2 = "SELECT * FROM BCPDelivery_Ratings WHERE Email = '".$row["Email"]."'";
		$result2 = mysqli_query($conn, $sql2);
		if ($result->num_rows > 0) 
		{
			while($row2 = $result2->fetch_assoc())
			{
				echo("<div>".$row2["Comment"]."</div>");
			}
		}
	}
}

//$stars = $row['RatingSum']/$row['NumberRatings'];
//$totalvotes = 400;
//displayStars($row["Stars"]);



mysqli_close($conn);
?>
<html>
    <head>
    <style>
	#posting {
		font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		width: 100%;
	}
	
	#posting td, #posting th {
		border: 1px solid #bfbfbf;
		padding: 8px;
	}
	
	#posting tr:nth-child(even){background-color: #ddd;}
	
	#posting tr:hover {background-color: #9A9A9A;}
	
	#posting th {
		padding-top: 12px;
		padding-bottom: 12px;
		text-align: left;
		background-color: #4CAF50;
		color: white;
	}
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
</style>
    </head>
    <body>
<?php

echo("<h3>Pending</h3>");
echo("
	<div class=\"row container\"><br>
	  <div class=\"column\" style=\"background-color:#aaa;\">
");
//ORDERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Orders", $userID));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Request</th><th>Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Price</th><th>Markup</th><th>Accepted By</th><th>Cancellation</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if (date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime($row["DeliveryTime"]))) 
		{
			echo(
					"<tr>".
					"<td>".$row["Order"]."</td>".
					"<td>".$row["FoodPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["ApproxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MaxMarkup"], 2)."</td>". //parse cents
					"<td>".$row["AcceptedEmail"]."</td>". //parse for name maybe?
					"<td>".
						"<form action=\"profile.php\" method=\"POST\" name=\"orderCancel\"/>".
							"<input type=\"hidden\" name=\"cancel"."Orders"."ID".$rowCounter."\" value=\"".$row["ID"]."\"/>".
							"<button type=\"submit\">Cancel Request</button>".
						"</form>".
					"</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 orders";
}

echo("
  </div>
  <div class=\"column\" style=\"background-color:#bbb;\">
");
//OFFERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Offers", $userID));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Offer</th><th>Order Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Max Price</th><th>Markup</th><th>Accepted By</th><th>Cancellation</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if (date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime($row["DeliveryTime"]))) 
		{
			echo(
					"<tr>".
					"<td>".$row["OrderItem"]."</td>".
					"<td>".$row["OrderPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["MaxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MarkupPrice"], 2)."</td>". //parse cents
					"<td>".$row["AcceptedEmail"]."</td>". //parse for name maybe?
					"<td>".
						"<form action=\"profile.php\" method=\"POST\" name=\"offerCancel\"/>".
							"<input type=\"hidden\" name=\"cancel"."Offers"."ID".$rowCounter."\" value=\"".$row["ID"]."\"/>".
							"<button type=\"submit\">Cancel Offer</button>".
						"</form>".
					"</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 offers";
}
echo("
  </div>
</div>
");

echo("<h3>Available for rating</h3>");
echo("
	<div class=\"row container\"><br>
	  <div class=\"column\" style=\"background-color:#aaa;\">
");
//ORDERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Orders", $userID));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Request</th><th>Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Price</th><th>Markup</th><th>Accepted By</th><th>Cancellation</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if ( $row["Email"] === $_SESSION['userEmail'] and date("Y-m-d H:i:s") > date("Y-m-d H:i:s", strtotime($row["DeliveryTime"]))) 
		{
			echo(
					"<tr>".
					"<td>".$row["Order"]."</td>".
					"<td>".$row["FoodPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["ApproxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MaxMarkup"], 2)."</td>". //parse cents
					"<td>".$row["AcceptedEmail"]."</td>". //parse for name maybe?
					"<td>".
						"<form action=\"rate.php\" method=\"POST\" name=\"orderRate\"/>".
							"<input type=\"hidden\" name=\"rateEmail\" value=\"".$row["AcceptedEmail"]."\"/>".
							"<button type=\"submit\">Rate Request</button>".
						"</form>".
					"</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 orders";
}

echo("
  </div>
  <div class=\"column\" style=\"background-color:#bbb;\">
");
//OFFERS
$rowCounter = 0;
$result = mysqli_query($conn, handleQueries("Offers", $userID));
if ($result->num_rows > 0) {
	//Table Header
	echo("<table id=\"posting\" class=\"table table-hover\"><tr><th>Offer</th><th>Order Location</th><th>Delivery Location</th><th>Delivery Time</th><th>Max Price</th><th>Markup</th><th>Accepted By</th><th>Cancellation</th></tr>");
	// output data of each row
	while($row = $result->fetch_assoc()) 
	{
		if ( $row["AcceptedEmail"] === $_SESSION['userEmail'] and date("Y-m-d H:i:s") < date("Y-m-d H:i:s", strtotime($row["DeliveryTime"]))) 
		{
			echo(
					"<tr>".
					"<td>".$row["OrderItem"]."</td>".
					"<td>".$row["OrderPlace"]."</td>".
					"<td>".$row["DeliveryPlace"]."</td>".
					"<td>".date("m/d h:i a", $row["DeliveryTime"])."</td>". //parse datatime
					"<td>".round(100*$row["MaxPrice"], 2)."</td>". //parse cents
					"<td>".round(100*$row["MarkupPrice"], 2)."</td>". //parse cents
					"<td>".$row["AcceptedEmail"]."</td>". //parse for name maybe?
					"<td>".
						"<form action=\"rate.php\" method=\"POST\" name=\"offerRate\"/>".
							"<input type=\"hidden\" name=\"rateEmail\" value=\"".$row["Email"]."\"/>".
							"<button type=\"submit\">Rate Offer</button>".
						"</form>".
					"</td>".
					"</tr>"
			);
			$rowCounter = $rowCounter + 1;
		}
	}
	echo("</table>");
} else {
	echo "0 offers";
}

echo("
  </div>
</div>
");


?>
    </body>
</html>