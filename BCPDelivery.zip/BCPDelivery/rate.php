<?php
session_start();
function validateUser() //checks userID cookie/session variable
{
	if($_SESSION['userID'] === "")
	{
		header( 'Location: http://times.bcp.org/webapps18/josh18/BCPDelivery/' ) ;
	}
}
validateUser();
?>


<!DOCTYPE html>
<html><head>
<title>Star Rating</title>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src = "https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <script>
    $(document).ready(function(){
        $("#ratingsForm").validate({
            // Make sure the form is submitted to the destination defined
            // in the "action" attribute of the form when valid
        });
        $("#submit").click(function(){
			
            $("#ratingsForm").submit();}
            return false;
        });
      });
	  
    </script>
    <script>
      function countChar(val) {
        var len = val.value.length;
         $('#charNum').text(400 - len);
      };
    </script>
</head>
<body>

<?php
$rateEmail = $_POST["rateEmail"];
?>

<h1>Rate your experience!</h1>
<link rel="stylesheet" href="ratestyle.css">
<form id="ratingsForm" name = "ratingsForm" method="post" action="rateConnect.php">
	<div class="stars">
		<input type="radio" name="star" class="star-1" id="star-1" value = "1">
		<label class="star-1" for="star-1">1</label>
		<input type="radio" name="star" class="star-2" id="star-2" value = "2">
		<label class="star-2" for="star-2">2</label>
		<input type="radio" name="star" class="star-3" id="star-3" value = "3">
		<label class="star-3" for="star-3">3</label>
		<input type="radio" name="star" class="star-4" id="star-4" value = "4">
		<label class="star-4" for="star-4">4</label>
		<input type="radio" name="star" class="star-5" id="star-5" value = "5">
		<label class="star-5" for="star-5">5</label>
        <?php echo("<input type=\"hidden\" name=\"rateEmail\" value=\"".$rateEmail."\"/>"); ?>
		<span></span>
	</div>
    Comment:
    <textarea id="comment" name = "comment" onkeyup="countChar(this)" rows="5" cols="50" maxlength="400"></textarea>
    <br>Characters left: <div id="charNum"></div>
    <button type="submit">Submit</button>
</form>


</body></html>